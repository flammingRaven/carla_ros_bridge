# Point Cloud Map Creation

Find documentation about the PCL recorder package [__here__](https://carla.readthedocs.io/projects/ros-bridge/en/latest/pcl_recorder/).